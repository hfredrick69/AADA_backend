Note: Documentation moved to docs/ folder - review for sensitive info before sharing
