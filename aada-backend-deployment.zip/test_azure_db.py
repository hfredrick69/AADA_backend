#!/usr/bin/env python3
"""
Test script to check Azure PostgreSQL database tables and structure
"""

import psycopg2
import sys

def test_azure_database():
    try:
        # Connection string for Azure PostgreSQL
        conn_string = "postgresql://aadaadmin:Universe1111@aada-pg-server27841.postgres.database.azure.com:5432/aada_local?sslmode=require"

        print("🔌 Connecting to Azure PostgreSQL database...")
        conn = psycopg2.connect(conn_string)
        cursor = conn.cursor()

        print("✅ Connection successful!")
        print("\n" + "="*60)

        # Get database version
        cursor.execute("SELECT version();")
        db_version = cursor.fetchone()[0]
        print(f"📊 Database Version: {db_version}")

        # List all tables in the public schema
        cursor.execute("""
            SELECT table_name
            FROM information_schema.tables
            WHERE table_schema = 'public'
            ORDER BY table_name;
        """)

        tables = cursor.fetchall()

        print(f"\n📋 Tables in 'aada_local' database ({len(tables)} total):")
        print("-" * 40)

        if tables:
            for i, (table_name,) in enumerate(tables, 1):
                print(f"{i:2d}. {table_name}")

                # Get row count for each table
                try:
                    cursor.execute(f"SELECT COUNT(*) FROM {table_name};")
                    count = cursor.fetchone()[0]
                    print(f"    └── Rows: {count}")
                except Exception as e:
                    print(f"    └── Error counting rows: {e}")
        else:
            print("   No tables found in the database")

        # Check for alembic version table specifically
        print(f"\n🔄 Alembic Migration Status:")
        cursor.execute("""
            SELECT version_num
            FROM alembic_version
            ORDER BY version_num DESC
            LIMIT 1;
        """)

        version = cursor.fetchone()
        if version:
            print(f"   Current migration: {version[0]}")
        else:
            print("   No migrations found")

        print("\n" + "="*60)
        print("✅ Database inspection complete!")

    except psycopg2.Error as e:
        print(f"❌ Database error: {e}")
        return False
    except Exception as e:
        print(f"❌ General error: {e}")
        return False
    finally:
        if 'cursor' in locals():
            cursor.close()
        if 'conn' in locals():
            conn.close()
            print("🔌 Database connection closed")

    return True

if __name__ == "__main__":
    success = test_azure_database()
    sys.exit(0 if success else 1)